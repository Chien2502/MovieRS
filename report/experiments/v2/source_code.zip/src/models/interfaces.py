"""Hợp đồng mô hình, tách điểm xếp hạng khỏi dự đoán số sao."""

from pathlib import Path
from typing import Protocol

import joblib
import numpy as np
import pandas as pd


class RankingModel(Protocol):
    supports_rating_prediction: bool

    def fit(self, ratings: pd.DataFrame): ...
    def score_items(self, user_id: int, movie_ids) -> np.ndarray: ...


def save_model(model: RankingModel, path: Path):
    """Chỉ nạp lại artifacts do dự án tạo; pickle không phải định dạng tải từ người lạ."""
    joblib.dump(model, path, compress=3)
